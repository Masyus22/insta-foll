# Insta-Foll
```
Tools ini dibuat untuk menambah
followers & likes instagram auto
jadi seleb wkwkwk slebew :v
```
> Script ini sewaktu-waktu bisa coid jadi jangan salahin author nya ya goblok.
## How to it?
```python
$ cd Insta-Foll
$ python main.py
```
> Get Token [click here](https://bit.ly/TokenInstaFoll)
## Support Me On
<b>• [Facebook](https://m.facebook.com/dhasilva.junior.3)</b>
<br>
<b>• [Youtube](https://www.youtube.com/channel/UCLRXFyMN0L8yH9F-xxOd7Og)</b>
</br>
